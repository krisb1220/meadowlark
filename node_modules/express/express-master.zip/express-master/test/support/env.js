
process.env.NODE_ENV = 'test';
process.env.NO_DEPRECATION = 'body-parser,express';
